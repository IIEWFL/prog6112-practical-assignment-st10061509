package prog6112;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class OrderTest {

    @Test
    public void testConstructor() {
        Order order = new Order("123", "John Doe");
        assertEquals("123", order.orderId);
        assertEquals("John Doe", order.customerName);
        assertEquals(0, order.items.length);
    }

    @Test
    public void testSetShippingCost() {
        Order order = new Order("123", "John Doe");
        order.setShippingCost(5.99);
        assertEquals(5.99, order.shippingCost, 0.01);
    }

    @Test
    public void testCalculateTotalCost_NoItems() {
        Order order = new Order("123", "John Doe");
        order.setShippingCost(5.99);
        assertEquals(5.99, order.calculateTotalCost(), 0.01);
    }


    @Test
    public void testPrintOrderReport() {
        Order order = new Order("123", "John Doe");
        order.setShippingCost(5.99);
        // You can use a mocking library to verify the output, or just verify that no exceptions are thrown
        order.printOrderReport();
    }
}