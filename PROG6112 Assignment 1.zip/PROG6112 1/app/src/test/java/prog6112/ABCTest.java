package prog6112;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class AppTest {

    @Test
    void TestSaveStudent() {
        // Create a new Student object
        Student student = new Student("S001", "John Doe", 20, "johndoe@example.com", "Computer Science");

        // Add the student to the ArrayList
        App.students.add(student);

        // Verify that the student is saved correctly
        assertEquals("S001", student.getId());
        assertEquals("John Doe", student.getName());
        assertEquals(20, student.getAge());
        assertEquals("johndoe@example.com", student.getEmail());
        assertEquals("Computer Science", student.getCourse());
    }

    @Test
    void TestSearchStudent() {
        // Create a new Student object
        Student student = new Student("S001", "John Doe", 20, "johndoe@example.com", "Computer Science");

        // Add the student to the ArrayList
        App.students.add(student);

        // Search for the student
        Student foundStudent = null;
        for (Student s : App.students) {
            if (s.getId().equals("S001")) {
                foundStudent = s;
                break;
            }
        }

        // Verify that the correct student is found
        assertNotNull(foundStudent);
        assertEquals("S001", foundStudent.getId());
        assertEquals("John Doe", foundStudent.getName());
        assertEquals(20, foundStudent.getAge());
        assertEquals("johndoe@example.com", foundStudent.getEmail());
        assertEquals("Computer Science", foundStudent.getCourse());
    }

    @Test
    void TestSearchStudent_StudentNotFound() {
        // Search for a non-existent student
        Student foundStudent = null;
        for (Student s : App.students) {
            if (s.getId().equals("S999")) {
                foundStudent = s;
                break;
            }
        }

        // Verify that no student is found
        assertNull(foundStudent);
    }

    @Test
    void TestDeleteStudent() {
        // Create a new Student object
        Student student = new Student("S001", "John Doe", 20, "johndoe@example.com", "Computer Science");

        // Add the student to the ArrayList
        App.students.add(student);

        // Delete the student
        for (Student s : App.students) {
            if (s.getId().equals("S001")) {
                App.students.remove(s);
                break;
            }
        }

        // Verify that the student is deleted
        assertEquals(0, App.students.size());
    }

    @Test
    void TestDeleteStudent_StudentNotFound() {
        // Delete a non-existent student
        for (Student s : App.students) {
            if (s.getId().equals("S999")) {
                App.students.remove(s);
                break;
            }
        }

        // Verify that no student is deleted
        assertEquals(0, App.students.size());
    }

    @Test
    void TestStudentAge_StudentAgeValid() {
        // Create a new Student object with a valid age
        Student student = new Student("S001", "John Doe", 20, "johndoe@example.com", "Computer Science");

        // Verify that the student's age is valid
        assertTrue(student.getAge() >= 16);
    }

    @Test
    void TestStudentAge_StudentAgeInvalid() {
        // Create a new Student object with an invalid age
        Student student = new Student("S001", "John Doe", 15, "johndoe@example.com", "Computer Science");

        // Verify that the student's age is invalid
        assertFalse(student.getAge() >= 16);
    }

    @Test
    void TestStudentAge_StudentAgeInvalidCharacter() {
    // Try to create a new Student object with an invalid age character
    try {
        Student student = new Student("S001", "John Doe", "abc", "johndoe@example.com", "Computer Science");
    } catch (NumberFormatException e) {
        // Verify that an exception is thrown
        assertNotNull(e);
    }
}
}
