
package prog6112;

import java.util.ArrayList;
import java.util.Scanner;

//This class represents a Student with attributes id, name, age, email, and course.
class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    // Constructor to create a new Student object
    public Student(String id, String name, int age2, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age2;
        this.email = email;
        this.course = course;
    }

    public Student(String id2, String name2, String string, String email2, String course2) {
    }

    // Getters for each attribute
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }
}

public class ABC {
    // ArrayList to store all Student objects
    static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initial prompt
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int initialChoice = scanner.nextInt();

        if (initialChoice == 1) {
            while (true) {
                displayMenu();
                int choice = getChoice(scanner);

                switch (choice) {
                    case 1:
                        captureNewStudent(scanner);
                        break;
                    case 2:
                        searchForStudent(scanner);
                        break;
                    case 3:
                        deleteStudent(scanner);
                        break;
                    case 4:
                        printStudentReport(scanner);
                        break;
                    case 5:
                        System.out.println("Exiting application.");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Exiting application.");
            return;
        }
    }

    // Display the menu options
    private static void displayMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application.");
    }

    // Get the user's choice
    private static int getChoice(Scanner scanner) {
        System.out.print("Enter your choice: ");
        return scanner.nextInt();
    }

    // Capture a new student
    private static void captureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.print("Enter the student id: ");
        String id = scanner.next();
        System.out.print("Enter the student name: ");
        String name = scanner.next();
        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            if (scanner.hasNextInt()) {
                age = scanner.nextInt();
                if (age >= 16) {
                    break;
                } else {
                    System.out
                            .println("You have entered an incorrect student age!! Please re-enter the student age >>");
                }
            } else {
                System.out.println("You have entered an incorrect student age!! Please re-enter the student age >>");
                scanner.next(); // Consume the invalid input
            }
        }
        System.out.print("Enter the student email: ");
        String email = scanner.next();
        System.out.print("Enter the student course: ");
        String course = scanner.next();

        // Create a new Student object and add it to the ArrayList
        Student student = new Student(id, name, age, email, course);
        students.add(student);

        System.out.println("Student details have been successfully saved!");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int choice = scanner.nextInt();
        if (choice != 1) {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }

    // Search for a student
    private static void searchForStudent(Scanner scanner) {
        System.out.println("SEARCH FOR A STUDENT");
        System.out.print("Enter the student id to search: ");
        String id = scanner.next();

        // Iterate through the ArrayList to find the student
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("STUDENT ID: " + student.getId());
                System.out.println("STUDENT NAME: " + student.getName());
                System.out.println("STUDENT AGE: " + student.getAge());
                System.out.println("STUDENT EMAIL: " + student.getEmail());
                System.out.println("STUDENT COURSE: " + student.getCourse());
                System.out.print("Enter (1) to launch menu or any other key to exit: ");
                int choice = scanner.nextInt();
                if (choice != 1) {
                    System.out.println("Exiting application.");
                    System.exit(0);
                }
                return;
            }
        }
        System.out.println("Student with Student Id: " + id + " was not found!");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int choice = scanner.nextInt();
        if (choice != 1) {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }

    // Delete a student
    private static void deleteStudent(Scanner scanner) {
        System.out.println("DELETE A STUDENT");
        System.out.print("Enter the student id to delete: ");
        String id = scanner.next();

        // Iterate through the ArrayList to delete the student
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println(
                        "Are you sure you want to delete student " + id + " from the system? Yes (y) to delete");
                String confirm = scanner.next().toLowerCase();
                if (confirm.equals("y")) {
                    students.remove(student);
                    System.out.println("Student with Student Id: " + id + " WAS deleted!");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                System.out.print("Enter (1) to launch menu or any other key to exit: ");
                int choice = scanner.nextInt();
                if (choice != 1) {
                    System.out.println("Exiting application.");
                    System.exit(0);
                }
                return;
            }
        }
        System.out.println("Student with Student Id: " + id + " was not found!");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int choice = scanner.nextInt();
        if (choice != 1) {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }

    // Print student
    private static void printStudentReport(Scanner scanner) {
        System.out.println("STUDENT REPORT");
        int count = 1;
        for (Student student : students) {
            System.out.println("STUDENT " + count);
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
            count++;
        }
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int choice = scanner.nextInt();
        if (choice != 1) {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }
}
