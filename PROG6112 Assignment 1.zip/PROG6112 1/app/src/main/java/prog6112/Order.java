package prog6112;

import java.util.Scanner;

public class Order {
    String orderId;
    String customerName;
    double shippingCost;
    private double totalCost;
    OrderItem[] items;

    public Order(String orderId, String customerName) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.items = new OrderItem[0];
    }

    public void addItem(Object object) {
        OrderItem[] newItems = new OrderItem[items.length + 1];
        System.arraycopy(items, 0, newItems, 0, items.length);
        newItems[items.length] = (OrderItem) object;
        items = newItems;
    }

    public void setShippingCost(double shippingCost) {
        this.shippingCost = shippingCost;
    }

    public double calculateTotalCost() {
        totalCost = shippingCost;
        for (OrderItem item : items) {
            totalCost += item.getPrice() * item.getQuantity();
        }
        return totalCost;
    }

    public void printOrderReport() {
        System.out.println("Order Report:");
        System.out.println("Order ID: " + orderId);
        System.out.println("Customer Name: " + customerName);
        System.out.println("Shipping Cost: $" + shippingCost);
        System.out.println("Items:");
        for (OrderItem item : items) {
            System.out.println("  - " + item.getItemName() + " (x" + item.getQuantity() + ") - $" + item.getPrice());
        }
        System.out.println("Total Cost: $" + calculateTotalCost());
    }

    static class OrderItem {
        private String itemId;
        private String itemName;
        private int quantity;
        private double price;

        public OrderItem(String itemId, String itemName, int quantity, double price) {
            this.itemId = itemId;
            this.itemName = itemName;
            this.quantity = quantity;
            this.price = price;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantity() {
            return quantity;
        }

        public String getItemName() {
            return itemName;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter order ID: ");
        String orderId = scanner.nextLine();

        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();

        Order order = new Order(orderId, customerName);

        System.out.print("Enter number of items to add: ");
        int numItems = scanner.nextInt();
        scanner.nextLine(); // consume newline left-over

        for (int i = 0; i < numItems; i++) {
            System.out.print("Enter item ID: ");
            String itemId = scanner.nextLine();

            System.out.print("Enter item name: ");
            String itemName = scanner.nextLine();

            System.out.print("Enter item price: ");
            double itemPrice = scanner.nextDouble();
            scanner.nextLine(); // consume newline left-over

            System.out.print("Enter quantity of " + itemName + ": ");
            int itemQuantity = scanner.nextInt();
            scanner.nextLine(); // consume newline left-over

            OrderItem item = new OrderItem(itemId, itemName, itemQuantity, itemPrice);
            order.addItem(item);
        }

        System.out.print("Enter shipping cost: ");
        double shippingCost = scanner.nextDouble();
        scanner.nextLine(); // consume newline left-over
        order.setShippingCost(shippingCost);

        System.out.println("Would you like to view the order report? (yes/no)");
        String response = scanner.nextLine();
        if (response.equalsIgnoreCase("yes")) {
            order.printOrderReport();
        }
    }
}


